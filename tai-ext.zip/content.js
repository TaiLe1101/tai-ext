const NEST_BASE_URL = "http://localhost:3000";

let chunkBuffer = [];
let voiceoverAudio = new Audio();
let currentPlayingId = null;
let originalVideo = null;
let isVoiceoverEnabled = false;
let pollingTimer = null;

function getVideoId() {
  return new URLSearchParams(window.location.search).get("v");
}

async function fetchClientCaptions() {
  try {
    const player = document.querySelector("#movie_player");
    const playerResponse = player?.getPlayerResponse ? player.getPlayerResponse() : window.ytInitialPlayerResponse;
    const tracks = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;

    if (!tracks || tracks.length === 0) return null;

    const selectedTrack = tracks.find(t => t.languageCode.startsWith("en")) || tracks[0];
    const res = await fetch(selectedTrack.baseUrl + "&fmt=json3");
    const data = await res.json();

    const parsed = [];
    for (const ev of data.events || []) {
      if (!ev.segs || ev.tStartMs === undefined) continue;
      const text = ev.segs.map(s => s.utf8 || "").join("").trim();
      if (!text || text === "\n") continue;

      const start = Number((ev.tStartMs / 1000).toFixed(2));
      const duration = Number(((ev.dDurationMs || 2000) / 1000).toFixed(2));
      parsed.push({ start, end: Number((start + duration).toFixed(2)), text });
    }
    return parsed;
  } catch (err) {
    console.error("Lỗi lấy caption từ client:", err);
    return null;
  }
}

function setupAudioController() {
  originalVideo = document.querySelector("video");
  if (!originalVideo) return;

  originalVideo.addEventListener("pause", () => {
    if (!voiceoverAudio.paused) voiceoverAudio.pause();
  });

  originalVideo.addEventListener("play", () => {
    if (isVoiceoverEnabled && voiceoverAudio.src && voiceoverAudio.paused && currentPlayingId !== null) {
      voiceoverAudio.play().catch(() => {});
    }
  });

  originalVideo.addEventListener("seeking", () => {
    voiceoverAudio.pause();
    currentPlayingId = null;
    originalVideo.volume = 1.0;
    fetchChunks(originalVideo.currentTime);
  });

  originalVideo.addEventListener("timeupdate", () => {
    if (!isVoiceoverEnabled || chunkBuffer.length === 0) return;

    const currTime = originalVideo.currentTime;
    const activeChunk = chunkBuffer.find(c => currTime >= c.start && currTime < c.end);

    if (activeChunk) {
      if (currentPlayingId !== activeChunk.id) {
        currentPlayingId = activeChunk.id;
        voiceoverAudio.src = `${NEST_BASE_URL}${activeChunk.audioUrl}`;

        const offset = currTime - activeChunk.start;
        const targetDuration = activeChunk.end - activeChunk.start;

        voiceoverAudio.onloadedmetadata = () => {
          if (voiceoverAudio.duration > targetDuration && targetDuration > 0) {
            voiceoverAudio.playbackRate = Math.min(1.35, voiceoverAudio.duration / targetDuration);
          } else {
            voiceoverAudio.playbackRate = 1.0;
          }
          voiceoverAudio.currentTime = Math.max(0, offset);
          voiceoverAudio.play().catch(() => {});
          originalVideo.volume = 0.2;
        };
      }
    } else {
      if (currentPlayingId !== null && !voiceoverAudio.paused) {
        voiceoverAudio.pause();
      }
      currentPlayingId = null;
      originalVideo.volume = 1.0;
    }
  });

  voiceoverAudio.addEventListener("ended", () => {
    originalVideo.volume = 1.0;
  });
}

async function fetchChunks(fromTime = 0) {
  const videoId = getVideoId();
  if (!videoId) return;

  try {
    const res = await fetch(`${NEST_BASE_URL}/voiceover/chunks?videoId=${videoId}&fromTime=${fromTime}`);
    const data = await res.json();

    if (data.chunks && data.chunks.length > 0) {
      data.chunks.forEach(newChunk => {
        if (!chunkBuffer.some(c => c.id === newChunk.id)) {
          chunkBuffer.push(newChunk);
        }
      });
      chunkBuffer.sort((a, b) => a.start - b.start);
    }
  } catch (err) {
    console.error("Lỗi kéo audio chunks:", err);
  }
}

function injectButton() {
  if (document.getElementById("btn-yt-voiceover")) return;

  const rightControls = document.querySelector(".ytp-right-controls");
  if (!rightControls) return;

  const btn = document.createElement("button");
  btn.id = "btn-yt-voiceover";
  btn.className = "ytp-button yt-voiceover-btn";
  btn.innerText = "🎙️ Dịch Voice";
  btn.title = "Bật lồng tiếng AI tiếng Việt";

  btn.onclick = async () => {
    const videoId = getVideoId();
    if (!videoId) return;

    btn.innerText = "⏳ Đang lấy sub...";
    const captions = await fetchClientCaptions();

    btn.innerText = "⏳ Đang đệm...";
    try {
      const res = await fetch(`${NEST_BASE_URL}/voiceover/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          videoId,
          subtitles: captions
        })
      });
      const data = await res.json();

      if (data.status === "NO_SUBTITLES") {
        btn.innerText = "⚠️ Không có sub";
        return;
      }

      isVoiceoverEnabled = true;
      btn.innerText = "🔊 Đang phát";
      setupAudioController();

      await fetchChunks(0);

      if (pollingTimer) clearInterval(pollingTimer);
      pollingTimer = setInterval(() => {
        if (originalVideo) fetchChunks(originalVideo.currentTime);
      }, 3500);

    } catch (err) {
      btn.innerText = "❌ Lỗi kết nối";
    }
  };

  rightControls.prepend(btn);
}

setInterval(() => {
  if (location.pathname === "/watch") {
    injectButton();
  }
}, 1000);